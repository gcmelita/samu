
export class Dados {
    valor: number;
    uf_id: number;
    ano: number;
}
